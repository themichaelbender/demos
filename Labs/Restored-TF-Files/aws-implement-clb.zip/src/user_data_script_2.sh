#!/bin/bash -xe
yum update -y
amazon-linux-extras install nginx1 -y
cd /usr/share/nginx/html
echo "Running on ec2-web-b | instance-id " > index.html
curl http://169.254.169.254/latest/meta-data/instance-id >> index.html
systemctl start nginx
systemctl enable nginx